ITEM.name = "Shrooms"
ITEM.model = "models/props_junk/cardboard_box002a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.desc = "A bag of mushrooms containing psilocybin, a powerful psychedelic substance of the tryptamine class."
ITEM.addictChance = 0 --no addictive properties
ITEM.effect = "drug_shrooms" --the effect
ITEM.category = "Drugs"
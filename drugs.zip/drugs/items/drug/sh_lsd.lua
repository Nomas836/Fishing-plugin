ITEM.name = "LSD"
ITEM.model = "models/props_junk/garbage_plasticbottle003a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.desc = "A powerful hallucinogenic drug first made by Albert Hofmann in 1938, its name stands for 'lysergic acid diethylamide'."
ITEM.addictChance = 0 --no addictive properties
ITEM.effect = "drug_lsd" --the effect
ITEM.category = "Drugs"
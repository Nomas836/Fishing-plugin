ITEM.name = "San Pedro"
ITEM.model = "models/props_junk/cardboard_box002a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.desc = "A cactus widely grown for ornamental purposes, it nevertheless contains a potent dose of mescaline and other psychoactive compounds."
ITEM.addictChance = 0 --no addictive properties
ITEM.effect = "drug_sanpedro" --the effect
ITEM.category = "Drugs"
ITEM.name = "Soil"
ITEM.model = "models/craphead_scripts/ch_farming/utility/dirtbag.mdl"
ITEM.desc = "A bag of soil."
ITEM.width = 1
ITEM.height = 1
ITEM.price = 10
ITEM.category = "Drugs"
ITEM.color = Color(50, 255, 50)
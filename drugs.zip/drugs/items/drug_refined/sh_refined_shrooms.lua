ITEM.name = "Refined Bulk Shrooms"
ITEM.desc = "A large box of freshly harvested psilocybin mushrooms."
ITEM.category = "Drugs"
ITEM.model = "models/props_junk/cardboard_box001a.mdl"
ITEM.width = 2
ITEM.height = 2
ITEM.name = "Refined Heroin Brick"
ITEM.desc = "A large amount of heroin pressed into a brick."
ITEM.category = "Drugs"
ITEM.model = "models/gdrugs/cocaine/cocaine.mdl"
ITEM.width = 2
ITEM.height = 2
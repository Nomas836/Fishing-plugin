ITEM.name = "Refined Bulk Opium"
ITEM.desc = "A large box of freshly harvested opium poppy."
ITEM.category = "Drugs"
ITEM.model = "models/props_junk/cardboard_box001a.mdl"
ITEM.width = 2
ITEM.height = 2
ITEM.name = "Refined Lysergic Acid Container"
ITEM.desc = "A large barrel of lysergic acid."
ITEM.category = "Drugs"
ITEM.model = "models/props_c17/oildrum001.mdl"
ITEM.width = 2
ITEM.height = 2

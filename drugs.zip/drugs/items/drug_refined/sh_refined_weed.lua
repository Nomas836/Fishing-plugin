ITEM.name = "Refined Marijuana Brick"
ITEM.desc = "A large amount of marijuana pressed into a brick."
ITEM.category = "Drugs"
ITEM.model = "models/props_junk/metal_paintcan001a.mdl"
ITEM.width = 2
ITEM.height = 2
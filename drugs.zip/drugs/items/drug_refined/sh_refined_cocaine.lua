ITEM.name = "Refined Cocaine Brick"
ITEM.desc = "A large amount of cocaine pressed into a brick."
ITEM.category = "Drugs"
ITEM.model = "models/gdrugs/cocaine/cocaine.mdl"
ITEM.width = 2
ITEM.height = 2
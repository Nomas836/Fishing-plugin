ITEM.name = "Refined Methaqualone Powder"
ITEM.desc = "A large jar of powdered methaqualone."
ITEM.category = "Drugs"
ITEM.model = "models/props_lab/jar01a.mdl"
ITEM.width = 2
ITEM.height = 2
ITEM.name = "Water Jug"
ITEM.model = "models/props_junk/garbage_milkcarton001a.mdl"
ITEM.desc = "A large container of water, useful for growing plants."
ITEM.price = 5
ITEM.category = "Drugs"
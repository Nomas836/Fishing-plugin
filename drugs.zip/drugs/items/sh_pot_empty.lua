ITEM.name = "Empty Pot"
ITEM.model = "models/props_junk/terracotta01.mdl"
ITEM.desc = "An empty pot."
ITEM.width = 2
ITEM.height = 2
ITEM.price = 10
--ITEM.permit = "permit_fake"
ITEM.category = "Drugs"
ITEM.data = { producing2 = 0, growth = 0 }
ITEM.color = Color(50, 255, 50)

ITEM.functions.Plant = {
	name = "Plant Weed",
	icon = "icon16/cog.png",
	sound = "buttons/lightswitch2.wav",
	onRun = function(item)
		local client = item.player
		local position = client:getItemDropPos()
		local inventory = client:getChar():getInv()
		
		local seed = inventory:getFirstItemOfType("weed_seed")	
		local soil = inventory:getFirstItemOfType("soil")	
			
		if (!seed or !soil) then
			client:notifyLocalized("You need soil and seeds!") return false
		end
			
		seed:remove()
		soil:remove()
			
		if(!inventory:add("weed_plant")) then --if the inventory has space, put it in the inventory
			nut.item.spawn("weed_plant", position) --if not, drop it on the ground
		end

		return true
	end
}

ITEM.functions.Plant2 = {
	name = "Plant Poppy",
	icon = "icon16/cog.png",
	sound = "buttons/lightswitch2.wav",
	onRun = function(item)
		local client = item.player
		local position = client:getItemDropPos()
		local inventory = client:getChar():getInv()
		
		local seed = inventory:getFirstItemOfType("poppy_seed")	
		local soil = inventory:getFirstItemOfType("soil")	
			
		if (!seed or !soil) then
			client:notifyLocalized("You need soil and seeds!") return false
		end
			
		seed:remove()
		soil:remove()
			
		if(!inventory:add("poppy_plant")) then --if the inventory has space, put it in the inventory
			nut.item.spawn("poppy_plant", position) --if not, drop it on the ground
		end

		return true
	end
}